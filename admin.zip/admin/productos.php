<?php
include 'conexion.php';
session_start();

// Verificar si es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Obtener categor�as para los dropdowns
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Procesar formularios
$error = '';
$success = '';
$current_product = null;

// Crear o actualizar producto
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);
    $stock = trim($_POST['stock']);
    $category_id = trim($_POST['category_id']);
    
    // Validaciones b�sicas
    if (empty($name) || empty($price)) {
        $error = "Nombre y precio son campos obligatorios";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "El precio debe ser un n�mero positivo";
    } elseif (!empty($stock) && (!is_numeric($stock) || $stock < 0)) {
        $error = "El stock debe ser un n�mero positivo";
    } else {
        // Manejar imagen
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/products/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $file_extension;
            $target_file = $upload_dir . $filename;
            
            // Validar tipo de archivo
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array(strtolower($file_extension), $allowed_types)) {
                $error = "Solo se permiten im�genes JPG, JPEG, PNG o GIF";
            } elseif ($_FILES['image']['size'] > 5000000) { // 5MB
                $error = "La imagen es demasiado grande (m�x. 5MB)";
            } elseif (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image = $target_file;
            } else {
                $error = "Error al subir la imagen";
            }
        }
        
        // Si no hay errores, procesar
        if (empty($error)) {
            try {
                if ($id) {
                    // Actualizar producto existente
                    $sql = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, category_id = ?";
                    $params = [$name, $description, $price, $stock, $category_id];
                    
                    if ($image) {
                        $sql .= ", image = ?";
                        $params[] = $image;
                        
                        // Eliminar imagen anterior si existe
                        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
                        $stmt->execute([$id]);
                        $old_image = $stmt->fetchColumn();
                        if ($old_image) {
                            @unlink($old_image);
                        }
                    }
                    
                    $sql .= " WHERE id = ?";
                    $params[] = $id;
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    $success = "Producto actualizado correctamente";
                } else {
                    // Crear nuevo producto
                    $sql = "INSERT INTO products (name, description, price, stock, category_id";
                    $values = "VALUES (?, ?, ?, ?, ?";
                    $params = [$name, $description, $price, $stock, $category_id];
                    
                    if ($image) {
                        $sql .= ", image";
                        $values .= ", ?";
                        $params[] = $image;
                    }
                    
                    $sql .= ") " . $values . ")";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    $success = "Producto creado correctamente";
                }
            } catch (PDOException $e) {
                $error = "Error en la base de datos: " . $e->getMessage();
            }
        }
    }
}

// Eliminar producto
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    try {
        // Obtener imagen para eliminarla
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $image = $stmt->fetchColumn();
        
        // Eliminar producto
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        // Eliminar imagen si existe
        if ($image) {
            @unlink($image);
        }
        
        $success = "Producto eliminado correctamente";
    } catch (PDOException $e) {
        $error = "Error al eliminar el producto: " . $e->getMessage();
    }
}

// Obtener producto para editar
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $current_product = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = "Error al cargar el producto: " . $e->getMessage();
    }
}

// Obtener todos los productos
try {
    $sql = "SELECT p.*, c.name AS category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            ORDER BY p.id DESC";
    $products = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error al cargar productos: " . $e->getMessage();
    $products = [];
}

// Configurar t�tulo
$page_title = "Administrar Productos";
include 'header.php';
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Administrar Productos</h1>
        <button type="button" class="btn btn-primary" onclick="resetForm()">
            <i class="fas fa-plus me-2"></i>Nuevo Producto
        </button>
    </div>

    <!-- Mensajes de error/�xito -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <!-- Formulario de producto -->
    <div class="card mb-5 shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">
                <?= $current_product ? 'Editar Producto' : 'Agregar Nuevo Producto' ?>
            </h5>
        </div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $current_product['id'] ?? '' ?>">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nombre del Producto *</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?= htmlspecialchars($current_product['name'] ?? '') ?>" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">Precio *</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="price" name="price" 
                                           value="<?= $current_product['price'] ?? '' ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stock" class="form-label">Stock</label>
                                <input type="number" min="0" class="form-control" id="stock" name="stock" 
                                       value="<?= $current_product['stock'] ?? '' ?>">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="category_id" class="form-label">Categor�a</label>
                            <select class="form-select" id="category_id" name="category_id">
                                <option value="">-- Seleccionar categor�a --</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>" 
                                        <?= ($current_product['category_id'] ?? '') == $category['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($category['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="description" class="form-label">Descripci�n</label>
                            <textarea class="form-control" id="description" name="description" rows="5"><?= htmlspecialchars($current_product['description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image" class="form-label">Imagen del Producto</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            
                            <?php if (!empty($current_product['image'])): ?>
                                <div class="mt-3">
                                    <p>Imagen actual:</p>
                                    <img src="<?= $current_product['image'] ?>" alt="Imagen actual" 
                                         class="img-thumbnail" style="max-height: 150px;">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-end mt-3">
                    <?php if ($current_product): ?>
                        <a href="products_crud.php" class="btn btn-secondary me-2">Cancelar</a>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>
                        <?= $current_product ? 'Actualizar Producto' : 'Crear Producto' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Lista de productos -->
    <div class="card shadow">
        <div class="card-header bg-light">
            <h5 class="mb-0">Lista de Productos</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Descripci�n</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Categor�a</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product['id'] ?></td>
                                <td>
                                    <?php if (!empty($product['image'])): ?>
                                        <img src="<?= $product['image'] ?>" alt="<?= $product['name'] ?>" 
                                             class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-secondary d-flex align-items-center justify-content-center" 
                                             style="width: 60px; height: 60px;">
                                            <i class="fas fa-image text-white"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td><?= htmlspecialchars(substr($product['description'], 0, 50)) ?><?= strlen($product['description']) > 50 ? '...' : '' ?></td>
                                <td>$<?= number_format($product['price'], 2) ?></td>
                                <td><?= $product['stock'] ?></td>
                                <td><?= $product['category_name'] ?? 'N/A' ?></td>
                                <td>
                                    <a href="products_crud.php?edit=<?= $product['id'] ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="products_crud.php?delete=<?= $product['id'] ?>" class="btn btn-sm btn-danger" 
                                       onclick="return confirm('�Est�s seguro de eliminar este producto?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (empty($products)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                    <h4>No hay productos registrados</h4>
                    <p class="text-muted">Comienza agregando tu primer producto usando el formulario superior</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    // Resetear formulario para nuevo producto
    function resetForm() {
        window.location.href = 'productos.php';
    }
</script>

<?php
include 'footer.php';
?>