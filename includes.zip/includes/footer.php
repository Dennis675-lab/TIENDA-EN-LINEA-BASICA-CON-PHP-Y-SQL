<?php
// footer.php
?>
        <!-- Cierre del main -->
    </main>

    <!-- Pie de p�gina -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <h4 class="mb-4"><i class="fas fa-shopping-bag me-2"></i>MiTienda</h4>
                    <p>Tu destino para las mejores compras en l�nea. Calidad garantizada y servicio excepcional.</p>
                    <div class="mt-4">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-pinterest fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4 mb-md-0">
                    <h5 class="mb-4">Enlaces R�pidos</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php" class="text-white text-decoration-none">Inicio</a></li>
                        <li class="mb-2"><a href="products.php" class="text-white text-decoration-none">Productos</a></li>
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Ofertas</a></li>
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Nuevos</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Contacto</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4 mb-md-0">
                    <h5 class="mb-4">Categor�as</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Electr�nicos</a></li>
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Hogar</a></li>
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Moda</a></li>
                        <li class="mb-2"><a href="#" class="text-white text-decoration-none">Deportes</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Juguetes</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5 class="mb-4">Contacto</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="fas fa-map-marker-alt me-2"></i> Av. Principal 123, Ciudad</li>
                        <li class="mb-3"><i class="fas fa-phone me-2"></i> +123 456 7890</li>
                        <li class="mb-3"><i class="fas fa-envelope me-2"></i> info@mitienda.com</li>
                        <li><i class="fas fa-clock me-2"></i> Lunes a Viernes: 9am - 8pm</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 mb-3 mb-md-0">
                    <p class="mb-0">&copy; 2023 MiTienda. Todos los derechos reservados.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <img src="https://via.placeholder.com/40x25" class="me-2" alt="Visa">
                    <img src="https://via.placeholder.com/40x25" class="me-2" alt="Mastercard">
                    <img src="https://via.placeholder.com/40x25" class="me-2" alt="PayPal">
                    <img src="https://via.placeholder.com/40x25" alt="American Express">
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Funciones comunes
        document.addEventListener('DOMContentLoaded', function() {
            // Actualizar badge del carrito
            function updateCartBadge(count) {
                const badge = document.querySelector('.badge-cart');
                if (badge) {
                    badge.textContent = count;
                }
            }
            
            // Ejemplo de funci�n para a�adir al carrito con AJAX
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const productId = this.dataset.id;
                    
                    // Simular llamada AJAX
                    fetch('add_to_cart.php?id=' + productId)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                updateCartBadge(data.cart_count);
                                // Mostrar notificaci�n
                            }
                        });
                });
            });
        });
    </script>
</body>
</html>